# Publication

Repository: https://github.com/mkluu3688/designer-drugs-labs-curbside-demo
Live demo: https://mkluu3688.github.io/designer-drugs-labs-curbside-demo/

Published using GitHub Pages from main, repository root. The repository contains the built static app and an editable React/Vite source archive. Local source remains in this directory. Local changes are not automatically pushed. Browser demo records are not included in the upload.
