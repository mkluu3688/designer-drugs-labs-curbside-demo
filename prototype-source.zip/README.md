# Designer Drugs Labs Curbside Pickup Prototype

Run `npm install` once, then `npm run dev -- --host 127.0.0.1 --port 4173`.
Open http://localhost:4173.

## Try it
1. Enter a sample last name and order number, select a space and color in Patient check-in, and submit.
2. Switch to Staff queue and click On my way.
3. Return to Patient check-in to see the updated status.
4. Mark the pickup completed in Staff queue.

Two tabs on the same browser origin sync automatically. Refreshing preserves demo records. This browser-only demo uses localStorage; it does NOT connect different phones or computers. It has no authentication, SMS, real staff alerts, prescription verification, payment or pharmacy integration. Do not enter real patient information or deploy as a patient service.

## Live no-code version
Use a pharmacy-approved HIPAA-enabled form account with an executed BAA and appropriately configured access and notifications. Copy the form structure, link the form to parking-sign QR codes, and assign staff to monitor its private submissions dashboard. Confirm pharmacy hours, telephone number, patient identification workflow, and retention settings before launch. Live prescription linking and two-way patient status require separate supported functionality.

## Patient support and delivery screen
The patient view automatically changes to a thank-you screen when its pickup becomes completed. Keep the patient tab open and update the order from a second staff tab on the same browser origin to try the live transition. The confirmation and thank-you screens include a tel:+14239542585 CTA and Monday–Friday 9 AM–6 PM Eastern hours, weekends closed, verified at https://www.designerdrugslabs.com/pages/contact-us on September 29, 2026. The official page uses EST; the interface labels local business hours as Eastern to avoid a fixed standard-time offset during daylight saving.

## Share this prototype
Live demo: https://mkluu3688.github.io/designer-drugs-labs-curbside-demo/

GitHub Pages serves the repository root on main. The initial publication contains a flattened production build and prototype-source.zip. The GitHub connector can read this repository but cannot write to it; the initial upload was made through the signed-in GitHub website. Each visitor has their own browser-local demo data.
